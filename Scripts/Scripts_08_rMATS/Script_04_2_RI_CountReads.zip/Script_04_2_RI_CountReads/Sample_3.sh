#!/bin/sh

module load R-base/4.0.1
module load R-cbrg/202109

cd /project/tsslab/mhanifi/RNAseq_data/Scripts/Scripts_08_rMATS/Script_04_2_RI_CountReads_Rscript/

Rscript Sample_3.sh

